# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


import json

class DaneOsobowe:
    def __init__(self, imie, nazwisko, adres, kod_pocztowy, pesel):
        self.imie = imie
        self.nazwisko = nazwisko
        self.adres = adres
        self.kod_pocztowy = kod_pocztowy
        self.pesel = pesel

    def to_dict(self):
        #Konwersja danych obiektu na słownik.
        return {
            "imie": self.imie,
            "nazwisko": self.nazwisko,
            "adres": self.adres,
            "kod_pocztowy": self.kod_pocztowy,
            "pesel": self.pesel,
        }

    @classmethod
    def from_dict(cls, data):
        #Tworzy obiekt klasy na podstawie słownika
        return cls(
            imie=data["imie"],
            nazwisko=data["nazwisko"],
            adres=data["adres"],
            kod_pocztowy=data["kod_pocztowy"],
            pesel=data["pesel"],
        )

    def zapisz_do_json(self, plik):
        with open(plik, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=4)

    @classmethod
    def odczytaj_z_json(cls, plik):
        #Odczytuje dane z pliku JSON i zwraca obiekt klasy
        with open(plik, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)


if __name__ == "__main__":
    # Tworzenie obiektu klasy DaneOsobowe
    osoba = DaneOsobowe(
        imie="Szymon",
        nazwisko="Waga",
        adres="Babilon",
        kod_pocztowy="25-400",
        pesel="12345678901"
    )

    # Zapis do pliku JSON
    plik_json = "dane_osobowe.json"
    osoba.zapisz_do_json(plik_json)
    print(f"Dane zapisano do pliku: {plik_json}")

    # Odczyt z pliku JSON i stworzenie nowego obiektu
    nowa_osoba = DaneOsobowe.odczytaj_z_json(plik_json)
    print("\nOdczytane dane:")
    print(f"Imię: {nowa_osoba.imie}")
    print(f"Nazwisko: {nowa_osoba.nazwisko}")
    print(f"Adres: {nowa_osoba.adres}")
    print(f"Kod pocztowy: {nowa_osoba.kod_pocztowy}")
    print(f"PESEL: {nowa_osoba.pesel}")