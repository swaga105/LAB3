# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def multiply_matrices(matrix_a, matrix_b):
    # Sprawdzenie czy macierze można pomnożyć
    if len(matrix_a[0]) != len(matrix_b):
        raise ValueError("Liczba kolumn w macierzy A musi być równa liczbie wierszy w macierzy B.")

    # Inicjalizacja macierzy wynikowej o wymiarach (liczba wierszy A) x (liczba kolumn B)
    result = [[0 for _ in range(len(matrix_b[0]))] for _ in range(len(matrix_a))]

    # Mnożenie macierzy
    for i in range(len(matrix_a)):  # Wiersze macierzy A
        for j in range(len(matrix_b[0])):  # Kolumny macierzy B
            for k in range(len(matrix_b)):  # Liczba kolumn macierzy A (lub wierszy macierzy B)
                result[i][j] += matrix_a[i][k] * matrix_b[k][j]

    return result


# Przykład użycia:
matrix_a = [
    [1, 2, 5],
    [4, 5, 6]
]

matrix_b = [
    [7, 8],
    [9, 10],
    [11, 12]
]

result = multiply_matrices(matrix_a, matrix_b)

#wynik
print("Macierz wynikowa:")
for row in result:
    print(row)
