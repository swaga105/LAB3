class WierzcholekTrie:
    def __init__(self):
        self.dzieci = {}
        self.wynik = []
        self.fail = None

def zbuduj_automat(slowa_kluczowe):
    korzen = WierzcholekTrie()

    for slowo in slowa_kluczowe:
        wierzcholek = korzen
        for znak in slowo:
            wierzcholek = wierzcholek.dzieci.setdefault(znak, WierzcholekTrie())
        wierzcholek.wynik.append(slowo)

    kolejka = []
    for wierzcholek in korzen.dzieci.values():
        kolejka.append(wierzcholek)
        wierzcholek.fail = korzen

    while kolejka:
        aktualny = kolejka.pop(0)
        for znak, nastepny in aktualny.dzieci.items():
            kolejka.append(nastepny)
            link = aktualny.fail
            while link and znak not in link.dzieci:
                link = link.fail
            nastepny.fail = link.dzieci[znak] if link else korzen
            nastepny.wynik += nastepny.fail.wynik

    return korzen

def wyszukaj_tekst(tekst, slowa_kluczowe):
    korzen = zbuduj_automat(slowa_kluczowe)
    wynik = {slowo: [] for slowo in slowa_kluczowe}

    wierzcholek = korzen
    for i, znak in enumerate(tekst):
        while wierzcholek and znak not in wierzcholek.dzieci:
            wierzcholek = wierzcholek.fail

        if not wierzcholek:
            wierzcholek = korzen
            continue

        wierzcholek = wierzcholek.dzieci[znak]
        for slowo in wierzcholek.wynik:
            wynik[slowo].append(i - len(slowo) + 1)

    return wynik

tekst1 = "hello worldhello"
tab1 = ["hello", "world"]
wynik1 = wyszukaj_tekst(tekst1, tab1)
print(wynik1)

tekst2 = "abxabcabcaby"
tab2 = ["ab", "abc", "aby"]
wynik2 = wyszukaj_tekst(tekst2, tab2)
print(wynik2)