def to_uppercase(func):
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return result.upper()
    return wrapper

@to_uppercase
def greet(name):
    return f"Hello, {name}"

print(greet("world"))
