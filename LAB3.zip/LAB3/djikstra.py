import sys

class Graf:

    def __init__(self, wierzcholki):
        self.liczba_wierzcholkow = wierzcholki
        self.graf = [[0 for _ in range(wierzcholki)] for _ in range(wierzcholki)]

    def rozwiazanie(self, dystans):
        print("Wierzchołek \tDystans od źródła")
        for wierzcholek in range(self.liczba_wierzcholkow):
            print(wierzcholek, "\t", dystans[wierzcholek])

    def minimalny_dystans(self, dystans, zbior_spt):
        min_wartosc = sys.maxsize
        min_indeks = -1

        for wierzcholek in range(self.liczba_wierzcholkow):
            if dystans[wierzcholek] < min_wartosc and not zbior_spt[wierzcholek]:
                min_wartosc = dystans[wierzcholek]
                min_indeks = wierzcholek

        return min_indeks

    def dijkstra(self, zrodlo):
        dystans = [sys.maxsize] * self.liczba_wierzcholkow
        dystans[zrodlo] = 0
        zbior_spt = [False] * self.liczba_wierzcholkow

        for _ in range(self.liczba_wierzcholkow):
            x = self.minimalny_dystans(dystans, zbior_spt)
            zbior_spt[x] = True

            for y in range(self.liczba_wierzcholkow):
                if self.graf[x][y] > 0 and not zbior_spt[y] and dystans[y] > dystans[x] + self.graf[x][y]:
                    dystans[y] = dystans[x] + self.graf[x][y]

        self.rozwiazanie(dystans)

if __name__ == "__main__":
    graf = Graf(9)
    graf.graf = [
        [0, 4, 0, 0, 0, 0, 0, 8, 0],
        [4, 0, 8, 0, 0, 0, 0, 11, 0],
        [0, 8, 0, 7, 0, 4, 0, 0, 2],
        [0, 0, 7, 0, 9, 14, 0, 0, 0],
        [0, 0, 0, 9, 0, 10, 0, 0, 0],
        [0, 0, 4, 14, 10, 0, 2, 0, 0],
        [0, 0, 0, 0, 0, 2, 0, 1, 6],
        [8, 11, 0, 0, 0, 0, 1, 0, 7],
        [0, 0, 2, 0, 0, 0, 6, 7, 0]
    ]

    graf.dijkstra(0)
