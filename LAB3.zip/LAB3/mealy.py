# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


class State:
    def __init__(self, name):
        self.name = name
        self.transitions = {}

    def add_transition(self, input_signal, next_state, output_signal):
        self.transitions[input_signal] = (next_state, output_signal)

    def get_transition(self, input_signal):
        return self.transitions.get(input_signal, (None, None))


class MealyMachine:
    def __init__(self, initial_state):
        self.current_state = initial_state  # Stan początkowy

    def process_input(self, input_sequence):
        outputs = []
        for input_signal in input_sequence:
            print(f"Stan bieżący: {self.current_state.name}, Wejście: {input_signal}")
            next_state, output_signal = self.current_state.get_transition(input_signal)
            if next_state is None:
                print("Błąd")
                break
            outputs.append(output_signal)
            print(f"Przejście do stanu: {next_state.name}, Wyjście: {output_signal}")
            self.current_state = next_state
        return outputs


if __name__ == "__main__":
    # Definiowanie stanów
    s0 = State("s0")
    s1 = State("s1")
    s2 = State("s2")

    #dla stanu s0
    s0.add_transition("00", s1, "1")
    s0.add_transition("10", s1, "0")
    s0.add_transition("01", s1, "1")
    s0.add_transition("11", s2, "0")

    #dla stanu s1
    s1.add_transition("00", s0, "0")
    s1.add_transition("11", s0, "1")
    s1.add_transition("01", s2, "0")
    s1.add_transition("10", s1, "1")

    #dla stanu s2
    s2.add_transition("00", s0, "0")
    s2.add_transition("11", s0, "0")
    s2.add_transition("01", s1, "1")
    s2.add_transition("10", s1, "1")

    # Tworzenie automatu i ustawienie stanu początkowego
    mealy_machine = MealyMachine(s0)

    # Przykładowa sekwencja wejść
    input_sequence = ["00", "10", "11", "01", "10", "00", "11", "00", "00"]
    print("\nSekwencja wejść:", input_sequence)
    output_sequence = mealy_machine.process_input(input_sequence)
    print("\nSekwencja wyjść:", output_sequence)
